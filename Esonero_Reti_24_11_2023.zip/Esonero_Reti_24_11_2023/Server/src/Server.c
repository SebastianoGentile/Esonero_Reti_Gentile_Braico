/*
 ============================================================================
 Name        : Server.c
 Author      : Sebastiano Gentile e Michele Braico
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : This is the Server where it receives the Client's request and
 	 	 	   returns the result of the mathematichal operation
 ============================================================================
 */
#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#endif
#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "protocol.h"

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void errorhandler(char *errorMessage) {
	perror(errorMessage);
}

int add(int number1, int number2) {
    return number1 + number2;
}

int mult(int number1, int number2) {
    return number1 * number2;
}

int sub(int number1, int number2) {
    return number1 - number2;
}

int division(int number1, int number2) {
    return number1 / number2;
}

int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	// create welcome socket
	int my_socket;
	my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (my_socket < 0) {
		errorhandler("socket creation failed.\n");
		clearwinsock();
		return -1;
	}
	int client_sockets[QLEN];
	int client_count = 0;

	//set connection settings
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = INADDR_ANY;// Server IP address
	sad.sin_port = htons(PROTO_PORT); // Server port

	// bind
	if (bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("bind() failed.\n");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}

	// listen
	if (listen(my_socket, QLEN) < 0) {
		errorhandler("listen() failed.\n");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}

	// accept new connection
	struct sockaddr_in cad; // structure for the client address
	int c_socket;       // socket descriptor for the client
	int client_len;          // the size of the client address
	printf("Waiting for a client to connect...\n\n");
	while (1) {

		client_len = sizeof(cad); // set the size of the client address
		if ((c_socket = accept(my_socket, (struct sockaddr*) &cad,
				&client_len)) < 0) {
			errorhandler("accept() failed.\n");
			// close connection
			closesocket(c_socket);
			clearwinsock();
			return 0;
		}

		printf("Handling client %s\n", inet_ntoa(cad.sin_addr));

		 // Aggiunta del nuovo socket client all'elenco
		        if (client_count < QLEN) {
		            client_sockets[client_count++] = c_socket;
		        } else {
		            // Gestisci il caso in cui la coda dei client è piena
		            // Puoi chiudere la nuova connessione o inviare un messaggio al client
		            printf("Queue full. Connection from %s closed.\n", inet_ntoa(cad.sin_addr));
		            close(c_socket);
		        }

		// send connection established message
        char buffer[BUFFER_SIZE];
        printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));
        sprintf(buffer, "Connection established with %s:%d\0", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

		if (send(c_socket, buffer, strlen(buffer), 0) != strlen(buffer)) {
			errorhandler(
					"send() sent a different number of bytes than expected");
			closesocket(c_socket);
			clearwinsock();
			return -1;
		}

		char data[sizeof(struct operation)];
		int bytes_received;

		// Receive the operation structure from the client
		bytes_received = recv(c_socket, data, sizeof(data), 0);
		if (bytes_received <= 0) {
		    errorhandler("recv() failed or connection closed prematurely");
		}

		// Process received data
		struct operation *received_operation = (struct operation *)data;
		int result;

		while (received_operation->operation != '=') {
		    switch (received_operation->operation) {
		        case '+':
		            result = add(received_operation->number1, received_operation->number2);
		            break;
		        case '-':
		            result = sub(received_operation->number1, received_operation->number2);
		            break;
		        case 'x':
		            result = mult(received_operation->number1, received_operation->number2);
		            break;
		        case '/':
		            result = division(received_operation->number1, received_operation->number2);
		            break;
		        default:
		            result = 0;
		            break;
		    }

		    // Send the result back to the client
		    bytes_received = send(c_socket, &result, sizeof(result), 0);
		    if (bytes_received <= 0) {
		        errorhandler("send() failed or connection closed prematurely");
		        break;  // Exit the loop if the sending fails
		    }

		    // Get the next operation from the client
		    bytes_received = recv(c_socket, data, sizeof(data), 0);
		    if (bytes_received <= 0) {
		        errorhandler("recv() failed or connection closed prematurely");
		        break;  // Exit the loop if the reception fails
		    }

		    // Process the received data
		    received_operation = (struct operation *)data;
		}

		// Close the connection
		closesocket(c_socket);

	}
	// Close welcome socket
	closesocket(my_socket);
	clearwinsock();
	return 0;

} // main end
