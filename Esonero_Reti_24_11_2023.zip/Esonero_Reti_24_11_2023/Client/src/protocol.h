/*
 * protocol.h
 *
 *  Created on: 23 nov 2022
 *      Author: Sebastiano Gentile e Michele Braico
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_PORT 60000
#define BUFFER_SIZE 64
#define NO_ERROR 0
#define QLEN 5

struct operation {
    char operation;
    int number1;
    int number2;
};

#endif /* PROTOCOL_H_ */
