/*
 ============================================================================
 Name        : Client.c
 Author      : Sebastiano Gentile e Michele Braico
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : This is the client where it asks the server to solve a simple mathematical operation
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include "protocol.h"

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void errorhandler(char *errorMessage) {
	printf("%s", errorMessage);
}

int main(int argc, char *argv[]) {
#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

	// create client socket
	int c_socket;
	c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP); //inizialize the socket to work with it :)
	if (c_socket < 0) {
		errorhandler("socket creation failed.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// set connection settings
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // IP del server
	sad.sin_port = htons(PROTO_PORT); // Server port

	// connection
	if (connect(c_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("Failed to connect.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	// receive from server
	char buffer[BUFFER_SIZE];
	int bytes_received = recv(c_socket, buffer, BUFFER_SIZE, 0);

	if (bytes_received <= 0) {
		errorhandler("recv() failed or connection closed prematurely");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	int i = 0;

	while(buffer[i] != '\0'){
		printf("%c", buffer[i]); // Print the echo buffer
		i++;
	}

	puts("");

	char operation[2]; //The array size is equal to 2, for the operation character and for '\0'
	int number1, number2; //The 2 numbers for the operation

	printf("Insert the operation, choosing between +(Sum), -(Difference), x(Product),"
			" /(Division) and 2 integers numbers. \n'=' and 2 random numbers to end\n");
	scanf("%1s%d%d", operation, &number1, &number2);

	// Send the operation structure to the server
	struct operation client_operation;
	client_operation.operation = operation[0];
	client_operation.number1 = number1;
	client_operation.number2 = number2;

	bytes_received = send(c_socket, &client_operation, sizeof(client_operation), 0);
	    if (bytes_received <= 0) {
	        errorhandler("send() failed or connection closed prematurely");
	    }

	//Enters the while if the operation character's different from '='
	while (operation[0] != '=') {

	    // Receive the result from the server
	    bytes_received = recv(c_socket, &result, sizeof(result), 0);
	    if (bytes_received <= 0) {
	        errorhandler("recv() failed or connection closed prematurely");
	    }

	    //Repeat the previous process
	    printf("Result: %d\n", result);

	    printf("Insert the operation, choosing between +(Sum), -(Difference), x(Product),"
	    		" /(Division) and 2 integers numbers. \n'=' and 2 random numbers to end\n");
	    scanf("%1s%d%d", operation, &number1, &number2);

	    struct operation client_operation;
	    client_operation.operation = operation[0];
	    client_operation.number1 = number1;
	    client_operation.number2 = number2;

	    bytes_received = send(c_socket, &client_operation, sizeof(client_operation), 0);
	        if (bytes_received <= 0) {
	            errorhandler("send() failed or connection closed prematurely");
	        }
	}

	//Close the client socket
	closesocket(c_socket);
	clearwinsock();
	return 0;
}// main end
