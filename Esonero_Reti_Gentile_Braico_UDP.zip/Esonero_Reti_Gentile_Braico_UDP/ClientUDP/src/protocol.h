/*
 * protocol.h
 *
 *  Created on: 11 12 2023
 *      Author: Gentile Sebastiano e Braico Michele
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_PORT 56700
#define BUFFER_SIZE 255
#define NO_ERROR 0

struct operation {
    char operation;
    int number1;
    int number2;
};

#endif /* PROTOCOL_H_ */
