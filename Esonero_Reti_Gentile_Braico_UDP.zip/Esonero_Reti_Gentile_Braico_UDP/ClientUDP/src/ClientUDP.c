/*
 ============================================================================
 Name        : ClientUDP.c
 Author      : Sebastiano Gentile e Michele Braico
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : This C program is a UDP client that communicates with a server.
 ============================================================================
 */
#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include "protocol.h"

void clearwinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

void errorhandler(char *errorMessage) {
    printf("%s", errorMessage);
	exit(1);  // Terminate program with error code 1

}

int main(int argc, char *argv[]) {
#if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
#endif

    char serverName[BUFFER_SIZE];

    strcpy(serverName, "srv.di.uniba.it");
    int port = PROTO_PORT;

    // create client socket
    int c_socket;
    c_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP); // Use SOCK_DGRAM for UDP
    if (c_socket < 0) {
        errorhandler("socket creation failed.\n");
        closesocket(c_socket);
        clearwinsock();
        return -1;
    }

    // Get host information
    struct hostent *host = gethostbyname(serverName);
    if (host == NULL) {
        errorhandler("Error getting host");
        clearwinsock();
        return EXIT_FAILURE;
    }

    // set connection settings
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad));
    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = inet_addr("127.0.0.1"); // IP of the server
    sad.sin_port = htons(port); // Server port

    int bytes_received;

    printf("Server name: %s (IP: %s, port: %d)\n", serverName,
    		inet_ntoa(*(struct in_addr*) host->h_addr), port);

    char operation[2]; // The array size is equal to 2, for the operation character and for '\0'
    int number1, number2; // The 2 numbers for the operation

    printf("Insert the operation, choosing between +(Sum), -(Difference), x(Product),"
           " /(Division) and 2 integers numbers. \n'=' and 2 random numbers to end\n");
    scanf("%1s%d%d", operation, &number1, &number2);

    // Send the operation structure to the server
    struct operation client_operation;
    client_operation.operation = operation[0];
    client_operation.number1 = number1;
    client_operation.number2 = number2;

    bytes_received = sendto(c_socket, &client_operation, sizeof(client_operation), 0,
    		(struct sockaddr*) &sad, sizeof(sad));
    if (bytes_received <= 0) {
        errorhandler("sendto() failed or connection closed prematurely");
    }

    // Enters the while loop if the operation character is different from '='
    while (operation[0] != '=') {
        // Receive the result from the server
        struct sockaddr_in server_address;
        int server_address_len = sizeof(server_address);

        float results;

        bytes_received = recvfrom(c_socket, &results, sizeof(results), 0,
        		(struct sockaddr*) &server_address, &server_address_len);
        if (bytes_received <= 0) {
        			errorhandler("recvfrom() failed or connection closed prematurely"); // Handle recvfrom failure
        }
        // Display the server's response
        printf("Received result from server %s, IP %s: %d %c %d = %.2f\n",
               gethostbyaddr((const char*)&server_address.sin_addr, sizeof(server_address.sin_addr), AF_INET)->h_name,
               inet_ntoa(server_address.sin_addr),
               number1, operation[0], number2, results);

        printf("Insert the operation, choosing between +(Sum), -(Difference), x(Product),"
               " /(Division) and 2 integers numbers. \n'=' and 2 random numbers to end\n");
        scanf("%1s%d%d", operation, &number1, &number2);

        struct operation client_operation;
        client_operation.operation = operation[0];
        client_operation.number1 = number1;
        client_operation.number2 = number2;

        bytes_received = sendto(c_socket, &client_operation,
        		sizeof(client_operation), 0, (struct sockaddr*) &sad,
				sizeof(sad));
        if (bytes_received <= 0) {
            errorhandler("sendto() failed or connection closed prematurely");
        }
    }

    // Close the client socket
    closesocket(c_socket);
    clearwinsock();
    return 0;
} // main end
