/*
 ============================================================================
 Name        : ServerUDP.c
 Author      : Sebastiano Gentile e Michele Braico
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : This C program is a UDP server that communicates with a client.
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "protocol.h"

void clearwinsock() {
#if defined WIN32
    WSACleanup();
#endif
}

void errorhandler(char *errorMessage) {
    perror(errorMessage);
}

// Function prototypes for arithmetic operations
float add(int number1, int number2);
float mult(int number1, int number2);
float sub(int number1, int number2);
float division(int number1, int number2);

int main(int argc, char *argv[]) {
#if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
#endif

    // create socket
    int my_socket;
    my_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (my_socket < 0) {
        errorhandler("socket creation failed.\n");
        clearwinsock();
        return -1;
    }

    // set connection settings
    struct sockaddr_in sad;
    memset(&sad, 0, sizeof(sad));
    sad.sin_family = AF_INET;
    sad.sin_addr.s_addr = INADDR_ANY;  // Server IP address
    sad.sin_port = htons(PROTO_PORT);  // Server port

    // bind
    if (bind(my_socket, (struct sockaddr *) &sad, sizeof(sad)) < 0) {
        errorhandler("bind() failed.\n");
        closesocket(my_socket);
        clearwinsock();
        return -1;
    }

    printf("Waiting for a client to connect...\n\n");

    struct sockaddr_in cad;  // structure for the client address
    int client_len;          // the size of the client address
    struct operation received_operation;
    char buffer[BUFFER_SIZE];

    while (1) {
        client_len = sizeof(cad);  // set the size of the client address

        // Receive data from the client
        int bytes_received = recvfrom(my_socket, &received_operation, sizeof(received_operation), 0,
                                      (struct sockaddr *) &cad, &client_len);

        if (bytes_received <= 0) {
            errorhandler("recvfrom() failed or connection closed prematurely");
            continue;  // Move to the next iteration
        }

        // send connection established message
        printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr),
               ntohs(cad.sin_port));

        // Display client information and requested operation
        printf("Request for operation '%c %d %d' from client %s, IP %s\n",
            received_operation.operation,
            received_operation.number1,
            received_operation.number2,
            gethostbyaddr((const char *)&cad.sin_addr, sizeof(cad.sin_addr), AF_INET)->h_name,
            inet_ntoa(cad.sin_addr));

        while (received_operation.operation != '=') {
            float result;

            // Perform the requested arithmetic operation
            switch (received_operation.operation) {
                case '+':
                    result = add(received_operation.number1, received_operation.number2);
                    break;
                case '-':
                    result = sub(received_operation.number1, received_operation.number2);
                    break;
                case 'x':
                    result = mult(received_operation.number1, received_operation.number2);
                    break;
                case '/':
                    result = division(received_operation.number1, received_operation.number2);
                    break;
                default:
                    result = 0;
                    break;
            }

            // Send the result back to the client
            int bytes_sent = sendto(my_socket, &result, sizeof(result), 0,
                                    (struct sockaddr *) &cad, sizeof(cad));

            if (bytes_sent <= 0) {
                errorhandler("sendto() failed or connection closed prematurely");
                break;  // Exit the loop if the sending fails
            }

            // Receive the next operation from the client
            bytes_received = recvfrom(my_socket, &received_operation, sizeof(received_operation), 0,
                                      (struct sockaddr *) &cad, &client_len);

            if (bytes_received <= 0) {
                errorhandler("recvfrom() failed or connection closed prematurely");
                break;  // Exit the loop if the reception fails
            }

            // Display client information and requested operation
            printf("Request for operation '%c %d %d' from client %s, IP %s\n",
                received_operation.operation,
                received_operation.number1,
                received_operation.number2,
                gethostbyaddr((const char *)&cad.sin_addr, sizeof(cad.sin_addr), AF_INET)->h_name,
                inet_ntoa(cad.sin_addr));
        }
    }

    // Close socket
    closesocket(my_socket);
    clearwinsock();
    return 0;
}

// Arithmetic operation functions
float add(int number1, int number2) {
    return number1 + number2;
}

float mult(int number1, int number2) {
    return number1 * number2;
}

float sub(int number1, int number2) {
    return number1 - number2;
}

float division(int number1, int number2) {
    return (float)number1 / (float)number2;
}
